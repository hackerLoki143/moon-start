/** Everything personal about the surprise lives here — edit freely. */
export const SURPRISE = {
  recipientName: "My Sunflower",
  senderSignature: "My Love",
  /** Birthday countdown target: 29 November 2026, midnight (viewer's local time). */
  birthday: new Date(2026, 10, 29, 0, 0, 0),
  /** Gift unlock moment: 11:11 AM, 29 November 2026 (viewer's local time). */
  activation: new Date(2026, 10, 29, 11, 11, 0),
  /** The second (WhatsApp) gift unlocks at 2:11 PM on the birthday. */
  whatsappGiftTime: new Date(2026, 10, 29, 14, 11, 0),
  /** Placeholder — replace with the real number incl. country code, digits only. */
  whatsappPhone: "910000000000",
  whatsappMessage:
    "I just opened my little universe 🌙🌻 Thank you for the most beautiful birthday surprise. I love you endlessly 💛",
  letterTitle: "Happy Birthday My Love 🎂",
  letter: [
    "On your special day, I just want to say that you are one of the most beautiful blessings in my life. Your smile makes my world softer, your presence makes my heart peaceful, and your love makes every day feel special.",
    "May Allah bless you with endless happiness, health, success, love, and every dream your heart silently prays for. I am so lucky to have you. ❤️",
  ],
} as const;

export interface TimeLeft {
  days: number;
  hours: number;
  minutes: number;
  seconds: number;
  totalMs: number;
  done: boolean;
}

export function getTimeLeft(target: Date, now: Date): TimeLeft {
  const totalMs = Math.max(0, target.getTime() - now.getTime());
  const totalSeconds = Math.floor(totalMs / 1000);
  return {
    days: Math.floor(totalSeconds / 86400),
    hours: Math.floor((totalSeconds % 86400) / 3600),
    minutes: Math.floor((totalSeconds % 3600) / 60),
    seconds: totalSeconds % 60,
    totalMs,
    done: totalMs === 0,
  };
}

export function isReached(target: Date, now: Date): boolean {
  return now.getTime() >= target.getTime();
}

/** Builds a wa.me link with a pre-filled message. Opening it never sends automatically. */
export function buildWhatsAppLink(phone: string, message: string): string {
  const digits = phone.replace(/\D/g, "");
  return `https://wa.me/${digits}?text=${encodeURIComponent(message)}`;
}

