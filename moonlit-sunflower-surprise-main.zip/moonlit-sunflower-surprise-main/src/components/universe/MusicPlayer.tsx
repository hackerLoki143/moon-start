import { Pause, Play } from "lucide-react";
import { cn } from "@/lib/utils";

export function MusicPlayer({ playing, onToggle }: { playing: boolean; onToggle: () => void }) {
  return (
    <button
      type="button"
      onClick={onToggle}
      aria-label={playing ? "Pause music" : "Play music"}
      aria-pressed={playing}
      className="group fixed bottom-5 right-5 z-50 flex items-center gap-3 rounded-full glass-card py-2 pl-2 pr-4 transition-all duration-500 hover:border-gold/60 hover:glow-gold"
    >
      <span
        className={cn(
          "relative grid h-11 w-11 place-items-center rounded-full bg-[repeating-radial-gradient(circle,var(--midnight)_0px,var(--midnight)_2px,var(--gift-deep)_3px)] ring-1 ring-gold/40",
          playing && "animate-vinyl",
        )}
      >
        <span className="h-4 w-4 rounded-full bg-gradient-gold" />
      </span>
      <span className="flex items-center gap-1.5 text-sm text-foreground">
        {playing ? <Pause className="h-4 w-4 text-gold" /> : <Play className="h-4 w-4 text-gold" />}
        <span className="hidden sm:inline">{playing ? "Pause" : "Play"}</span>
      </span>
      {playing && (
        <span className="flex h-4 items-end gap-0.5" aria-hidden>
          {[0, 1, 2].map((i) => (
            <span
              key={i}
              className="w-0.5 rounded-full bg-gold animate-pulse"
              style={{ height: `${8 + i * 4}px`, animationDelay: `${i * 0.2}s` }}
            />
          ))}
        </span>
      )}
    </button>
  );
}
