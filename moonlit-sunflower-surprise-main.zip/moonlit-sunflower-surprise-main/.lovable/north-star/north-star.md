<!-- Lovable wrote this file; it is not part of your task. Keep it, and ask the user before deleting or reverting it. -->

# North star

The birthday partner feels deeply loved and celebrated on their special day.

## Metric

People who open the gift and see the birthday letter each month
