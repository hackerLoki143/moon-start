import { describe, expect, it } from "vitest";
import { SURPRISE, buildWhatsAppLink, getTimeLeft, isReached } from "./surprise";

describe("surprise dates", () => {
  it("birthday is 29 November 2026", () => {
    expect(SURPRISE.birthday.getFullYear()).toBe(2026);
    expect(SURPRISE.birthday.getMonth()).toBe(10);
    expect(SURPRISE.birthday.getDate()).toBe(29);
  });

  it("gift unlocks at 11:11 AM on 29 November 2026", () => {
    const a = SURPRISE.activation;
    expect([a.getFullYear(), a.getMonth(), a.getDate(), a.getHours(), a.getMinutes()]).toEqual([
      2026, 10, 29, 11, 11,
    ]);
  });

  it("gift stays locked one second before 11:11 and unlocks exactly at 11:11", () => {
    expect(isReached(SURPRISE.activation, new Date(2026, 10, 29, 11, 10, 59))).toBe(false);
    expect(isReached(SURPRISE.activation, new Date(2026, 10, 29, 11, 11, 0))).toBe(true);
  });
});

describe("countdown", () => {
  it("splits remaining time into days, hours, minutes, seconds", () => {
    const now = new Date(2026, 10, 23, 12, 40, 0);
    const t = getTimeLeft(SURPRISE.birthday, now);
    expect([t.days, t.hours, t.minutes, t.seconds]).toEqual([5, 11, 20, 0]);
    expect(t.done).toBe(false);
  });

  it("reaches zero and never goes negative after the birthday", () => {
    const t = getTimeLeft(SURPRISE.birthday, new Date(2026, 10, 30));
    expect([t.days, t.hours, t.minutes, t.seconds, t.done]).toEqual([0, 0, 0, 0, true]);
  });
});

describe("WhatsApp link", () => {
  it("uses the wa.me format with an encoded pre-filled message", () => {
    expect(buildWhatsAppLink("+91 98765-43210", "Hi love 🌙")).toBe(
      "https://wa.me/919876543210?text=Hi%20love%20%F0%9F%8C%99",
    );
  });
});


describe("WhatsApp gift", () => {
  it("unlocks at 2:11 PM on 29 November 2026", () => {
    expect(isReached(SURPRISE.whatsappGiftTime, new Date(2026, 10, 29, 14, 10, 59))).toBe(false);
    expect(isReached(SURPRISE.whatsappGiftTime, new Date(2026, 10, 29, 14, 11, 0))).toBe(true);
  });
});
