import { useEffect, useRef } from "react";

interface Star {
  x: number;
  y: number;
  z: number;
  r: number;
  phase: number;
  speed: number;
  warm: boolean;
}
interface Shooter {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
}
interface Mote {
  x: number;
  y: number;
  r: number;
  vy: number;
  phase: number;
}

/** Canvas starfield: twinkling stars with depth parallax, shooting stars and golden motes. */
export function Starfield({ pointer }: { pointer: React.RefObject<{ x: number; y: number }> }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext("2d");
    if (!canvas || !ctx) return;
    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

    const gold = getComputedStyle(document.documentElement).getPropertyValue("--gold").trim();
    const moon = getComputedStyle(document.documentElement).getPropertyValue("--moon").trim();

    let w = 0;
    let h = 0;
    let stars: Star[] = [];
    let motes: Mote[] = [];
    const shooters: Shooter[] = [];
    let nextShooter = performance.now() + 2500;
    let raf = 0;
    const eased = { x: 0, y: 0 };

    const resize = () => {
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      w = window.innerWidth;
      h = window.innerHeight;
      canvas.width = w * dpr;
      canvas.height = h * dpr;
      canvas.style.width = `${w}px`;
      canvas.style.height = `${h}px`;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      const count = Math.round(Math.min(260, (w * h) / 5200));
      stars = Array.from({ length: count }, () => ({
        x: Math.random() * w,
        y: Math.random() * h,
        z: Math.random() * 0.9 + 0.1,
        r: Math.random() * 1.3 + 0.3,
        phase: Math.random() * Math.PI * 2,
        speed: Math.random() * 1.5 + 0.5,
        warm: Math.random() < 0.18,
      }));
      motes = Array.from({ length: Math.round(count / 7) }, () => ({
        x: Math.random() * w,
        y: Math.random() * h,
        r: Math.random() * 1.8 + 0.6,
        vy: Math.random() * 0.25 + 0.08,
        phase: Math.random() * Math.PI * 2,
      }));
    };
    resize();
    window.addEventListener("resize", resize);

    const draw = (t: number) => {
      ctx.clearRect(0, 0, w, h);
      const p = pointer.current ?? { x: 0, y: 0 };
      eased.x += (p.x - eased.x) * 0.05;
      eased.y += (p.y - eased.y) * 0.05;

      for (const s of stars) {
        const tw = reduced ? 0.8 : 0.55 + 0.45 * Math.sin(t * 0.001 * s.speed + s.phase);
        const px = s.x - eased.x * 30 * s.z;
        const py = s.y - eased.y * 20 * s.z;
        ctx.globalAlpha = tw;
        ctx.fillStyle = s.warm ? gold : moon;
        ctx.beginPath();
        ctx.arc(px, py, s.r * (0.6 + s.z * 0.6), 0, Math.PI * 2);
        ctx.fill();
        if (s.r > 1.3 && tw > 0.85) {
          ctx.globalAlpha = (tw - 0.85) * 3;
          ctx.fillRect(px - 4, py - 0.3, 8, 0.6);
          ctx.fillRect(px - 0.3, py - 4, 0.6, 8);
        }
      }

      for (const m of motes) {
        if (!reduced) {
          m.y -= m.vy;
          m.x += Math.sin(t * 0.0006 + m.phase) * 0.2;
          if (m.y < -10) {
            m.y = h + 10;
            m.x = Math.random() * w;
          }
        }
        ctx.globalAlpha = 0.35 + 0.3 * Math.sin(t * 0.002 + m.phase);
        ctx.fillStyle = gold;
        ctx.shadowColor = gold;
        ctx.shadowBlur = 8;
        ctx.beginPath();
        ctx.arc(m.x - eased.x * 45, m.y - eased.y * 30, m.r, 0, Math.PI * 2);
        ctx.fill();
        ctx.shadowBlur = 0;
      }

      if (!reduced && t > nextShooter) {
        const fromLeft = Math.random() < 0.5;
        shooters.push({
          x: fromLeft ? Math.random() * w * 0.5 : w * 0.5 + Math.random() * w * 0.5,
          y: Math.random() * h * 0.35,
          vx: (fromLeft ? 1 : -1) * (7 + Math.random() * 4),
          vy: 3 + Math.random() * 2,
          life: 1,
        });
        nextShooter = t + 3500 + Math.random() * 5000;
      }
      for (let i = shooters.length - 1; i >= 0; i--) {
        const s = shooters[i]!;
        s.x += s.vx;
        s.y += s.vy;
        s.life -= 0.012;
        const grad = ctx.createLinearGradient(s.x, s.y, s.x - s.vx * 14, s.y - s.vy * 14);
        grad.addColorStop(0, moon);
        grad.addColorStop(1, "transparent");
        ctx.globalAlpha = Math.max(0, s.life);
        ctx.strokeStyle = grad;
        ctx.lineWidth = 1.6;
        ctx.beginPath();
        ctx.moveTo(s.x, s.y);
        ctx.lineTo(s.x - s.vx * 14, s.y - s.vy * 14);
        ctx.stroke();
        if (s.life <= 0) shooters.splice(i, 1);
      }
      ctx.globalAlpha = 1;
      raf = requestAnimationFrame(draw);
    };
    raf = requestAnimationFrame(draw);

    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("resize", resize);
    };
  }, [pointer]);

  return <canvas ref={canvasRef} className="pointer-events-none absolute inset-0" aria-hidden />;
}
