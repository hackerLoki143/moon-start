/** Golden sunflower petals drifting down the screen. Deterministic layout (SSR-safe). */
export function FallingPetals({ count = 14 }: { count?: number }) {
  const petals = Array.from({ length: count }, (_, i) => {
    const r = (n: number) => ((Math.sin((i + 1) * n) + 1) / 2);
    return {
      left: `${Math.round(r(12.9898) * 100)}%`,
      size: 10 + Math.round(r(78.233) * 12),
      duration: 14 + Math.round(r(37.719) * 14),
      delay: -Math.round(r(4.123) * 26),
      drift: `${Math.round((r(9.77) - 0.5) * 240)}px`,
      spin: `${360 + Math.round(r(3.3) * 540)}deg`,
    };
  });
  return (
    <div className="pointer-events-none fixed inset-0 z-0 overflow-hidden" aria-hidden>
      {petals.map((p, i) => (
        <svg
          key={i}
          className="petal opacity-80"
          viewBox="0 0 20 40"
          width={p.size}
          height={p.size * 2}
          style={
            {
              left: p.left,
              animationDuration: `${p.duration}s`,
              animationDelay: `${p.delay}s`,
              "--drift": p.drift,
              "--spin": p.spin,
            } as React.CSSProperties
          }
        >
          <path d="M10 1 C 19 12, 18 30, 10 39 C 2 30, 1 12, 10 1 Z" className="fill-petal" />
          <path d="M10 6 C 12 16, 12 28, 10 34" className="stroke-petal-deep opacity-60" strokeWidth="1.2" fill="none" />
        </svg>
      ))}
    </div>
  );
}
