import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { Sunflower } from "./Sunflower";

export function WelcomeScreen({ leaving, onEnter }: { leaving: boolean; onEnter: () => void }) {
  return (
    <section
      className={cn(
        "fixed inset-0 z-50 flex flex-col items-center justify-center px-6 text-center transition-all duration-[1400ms] ease-out",
        leaving && "pointer-events-none scale-110 opacity-0 blur-md",
      )}
    >
      <div className="absolute inset-0 bg-midnight/40" />
      <div className="relative flex flex-col items-center">
        <div className="mb-8 animate-float animate-pulse-glow">
          <Sunflower size={78} stem={false} swayDuration={6} />
        </div>
        <p className="animate-rise-in font-sans text-xs uppercase tracking-[0.5em] text-moon/80">
          for you, tonight
        </p>
        <h1
          className="mt-6 max-w-3xl animate-rise-in font-display text-4xl font-light italic leading-tight text-foreground text-glow-moon sm:text-6xl md:text-7xl"
          style={{ animationDelay: "0.3s" }}
        >
          A little universe is waiting for you…{" "}
          <span className="not-italic">🌙</span>
        </h1>
        <div className="mt-12 animate-rise-in" style={{ animationDelay: "0.9s" }}>
          <Button variant="celestial" size="xl" onClick={onEnter}>
            Enter My Universe ✨
          </Button>
        </div>
        <p
          className="mt-6 animate-rise-in text-xs tracking-widest text-muted-foreground"
          style={{ animationDelay: "1.3s" }}
        >
          turn your sound on 🎵
        </p>
      </div>
    </section>
  );
}
