import { cn } from "@/lib/utils";

interface SunflowerProps {
  size?: number;
  stem?: boolean;
  bloom?: boolean;
  swayDuration?: number;
  delay?: number;
  className?: string;
}

/** Hand-built SVG sunflower that sways in the wind and can bloom open. */
export function Sunflower({
  size = 120,
  stem = true,
  bloom = false,
  swayDuration = 5,
  delay = 0,
  className,
}: SunflowerProps) {
  const height = stem ? size * 2 : size;
  return (
    <svg
      viewBox={stem ? "0 0 100 200" : "0 0 100 100"}
      width={size}
      height={height}
      className={cn("animate-sway overflow-visible", className)}
      style={
        {
          "--sway-duration": `${swayDuration}s`,
          animationDelay: `${delay}s`,
        } as React.CSSProperties
      }
      aria-hidden
    >
      {stem && (
        <g>
          <path d="M50 60 C 46 110, 54 150, 50 200" className="stroke-stem" strokeWidth="4" fill="none" />
          <path d="M50 125 C 30 110, 18 118, 12 128 C 28 134, 40 132, 50 125 Z" className="fill-leaf" />
          <path d="M50 150 C 70 136, 84 142, 90 152 C 74 160, 60 158, 50 150 Z" className="fill-leaf" />
        </g>
      )}
      <g
        className={cn("sunflower-head", bloom && "is-blooming")}
        style={{ animationDelay: `${delay}s` }}
      >
        {Array.from({ length: 16 }, (_, i) => (
          <ellipse
            key={`o${i}`}
            cx="50"
            cy="22"
            rx="7"
            ry="19"
            className="fill-petal-deep"
            transform={`rotate(${i * 22.5 + 11} 50 50)`}
          />
        ))}
        {Array.from({ length: 16 }, (_, i) => (
          <ellipse
            key={`i${i}`}
            cx="50"
            cy="25"
            rx="6"
            ry="17"
            className="fill-petal"
            transform={`rotate(${i * 22.5} 50 50)`}
          />
        ))}
        <circle cx="50" cy="50" r="17" className="fill-seed" />
        <circle cx="50" cy="50" r="12" className="fill-seed-light opacity-60" />
        {Array.from({ length: 18 }, (_, i) => {
          const a = i * 2.4;
          const d = Math.sqrt(i + 1) * 3.2;
          return (
            <circle
              key={`s${i}`}
              cx={50 + Math.cos(a) * d}
              cy={50 + Math.sin(a) * d}
              r="1.2"
              className="fill-seed opacity-80"
            />
          );
        })}
      </g>
    </svg>
  );
}
