import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { SURPRISE, buildWhatsAppLink } from "@/lib/surprise";

const FULL_TEXT = SURPRISE.letter.join("\n\n");

function useTypewriter(text: string, active: boolean, speed = 38) {
  const [count, setCount] = useState(0);
  useEffect(() => {
    if (!active) return;
    if (count >= text.length) return;
    const ch = text[count];
    const pause = ch === "\n" ? 260 : ch === "." || ch === "," || ch === "—" ? 180 : speed;
    const id = window.setTimeout(() => setCount((c) => c + 1), pause);
    return () => window.clearTimeout(id);
  }, [active, count, text, speed]);
  return { shown: text.slice(0, count), done: count >= text.length, skip: () => setCount(text.length) };
}

export function LoveLetter({ onRead, onReplay }: { onRead?: () => void; onReplay?: () => void }) {
  const [opened, setOpened] = useState(false);
  const { shown, done, skip } = useTypewriter(FULL_TEXT, opened);
  const link = buildWhatsAppLink(SURPRISE.whatsappPhone, SURPRISE.whatsappMessage);

  useEffect(() => {
    if (done && opened) onRead?.();
  }, [done, opened, onRead]);

  return (
    <div className="mx-auto w-full max-w-xl animate-rise-in">
      <article className="paper relative rounded-3xl px-7 py-9 text-ink sm:px-12 sm:py-12">
        <span className="absolute -top-5 left-1/2 grid h-10 w-10 -translate-x-1/2 place-items-center rounded-full bg-gradient-gold text-lg glow-gold" aria-hidden>
          💌
        </span>
        <p className="text-center font-script text-4xl text-ink sm:text-5xl">{SURPRISE.letterTitle}</p>
        <div className="mx-auto mt-3 h-px w-24 bg-gradient-gold" />

        {!opened ? (
          <div className="mt-8 flex flex-col items-center gap-4 text-center">
            <p className="font-hand text-xl text-ink/80">A few words I've been saving just for today…</p>
            <Button variant="celestial" size="xl" onClick={() => setOpened(true)}>
              Open Your Surprise Message 💌
            </Button>
          </div>
        ) : (
          <div className="mt-6">
            <p
              className="min-h-[10rem] whitespace-pre-line font-hand text-xl leading-relaxed sm:text-2xl"
              aria-live="polite"
            >
              {shown}
              {!done && <span className="ml-0.5 inline-block h-6 w-0.5 translate-y-1 bg-ink animate-caret" />}
            </p>
            {done ? (
              <p className="mt-6 text-right font-script text-3xl text-ink animate-rise-in">
                Forever yours,
                <br />
                {SURPRISE.senderSignature} 🌙
              </p>
            ) : (
              <button
                type="button"
                onClick={skip}
                className="mt-4 text-xs uppercase tracking-[0.3em] text-ink/50 transition-colors hover:text-ink"
              >
                show all
              </button>
            )}
          </div>
        )}
      </article>

      {done && (
        <div className="mt-8 flex flex-col items-center justify-center gap-4 animate-rise-in sm:flex-row">
          <Button variant="whatsapp" size="xl" asChild>
            <a href={link} target="_blank" rel="noopener noreferrer">
              Send / Open on WhatsApp 💚
            </a>
          </Button>
          {onReplay && (
            <Button variant="glass" size="xl" onClick={onReplay}>
              Replay Magic ✨
            </Button>
          )}
        </div>
      )}
    </div>
  );
}
