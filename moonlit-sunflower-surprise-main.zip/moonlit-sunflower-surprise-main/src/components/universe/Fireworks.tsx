import { useEffect, useRef } from "react";

interface Spark {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  color: string;
  size: number;
}

/** Soft golden fireworks + glitter, rendered for `duration` ms whenever `active` turns on. */
export function Fireworks({ active, duration = 9000 }: { active: boolean; duration?: number }) {
  const ref = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    if (!active) return;
    const canvas = ref.current;
    const ctx = canvas?.getContext("2d");
    if (!canvas || !ctx) return;
    const css = getComputedStyle(document.documentElement);
    const palette = ["--gold", "--gold-soft", "--petal-deep", "--moon", "--petal"].map((v) =>
      css.getPropertyValue(v).trim(),
    );
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const w = window.innerWidth;
    const h = window.innerHeight;
    canvas.width = w * dpr;
    canvas.height = h * dpr;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);

    const sparks: Spark[] = [];
    const start = performance.now();
    let nextBurst = start;
    let raf = 0;

    const burst = () => {
      const cx = w * (0.15 + Math.random() * 0.7);
      const cy = h * (0.15 + Math.random() * 0.4);
      const color = palette[Math.floor(Math.random() * palette.length)]!;
      const n = 70 + Math.floor(Math.random() * 40);
      for (let i = 0; i < n; i++) {
        const a = (i / n) * Math.PI * 2;
        const sp = 2 + Math.random() * 3.5;
        sparks.push({ x: cx, y: cy, vx: Math.cos(a) * sp, vy: Math.sin(a) * sp, life: 1, color, size: 1.6 + Math.random() * 1.4 });
      }
    };

    const tick = (t: number) => {
      const elapsed = t - start;
      if (elapsed < duration && t > nextBurst) {
        burst();
        nextBurst = t + 450 + Math.random() * 650;
      }
      if (elapsed < duration) {
        // golden glitter rain
        sparks.push({ x: Math.random() * w, y: -10, vx: (Math.random() - 0.5) * 0.6, vy: 1 + Math.random() * 1.5, life: 1.4, color: palette[0]!, size: 1 + Math.random() * 1.5 });
      }
      ctx.clearRect(0, 0, w, h);
      for (let i = sparks.length - 1; i >= 0; i--) {
        const s = sparks[i]!;
        s.vx *= 0.985;
        s.vy = s.vy * 0.985 + 0.035;
        s.x += s.vx;
        s.y += s.vy;
        s.life -= 0.011;
        if (s.life <= 0 || s.y > h + 20) {
          sparks.splice(i, 1);
          continue;
        }
        ctx.globalAlpha = Math.min(1, s.life);
        ctx.fillStyle = s.color;
        ctx.shadowColor = s.color;
        ctx.shadowBlur = 10;
        ctx.beginPath();
        ctx.arc(s.x, s.y, s.size, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.shadowBlur = 0;
      if (elapsed < duration || sparks.length) raf = requestAnimationFrame(tick);
      else ctx.clearRect(0, 0, w, h);
    };
    raf = requestAnimationFrame(tick);
    return () => {
      cancelAnimationFrame(raf);
      ctx.clearRect(0, 0, w, h);
    };
  }, [active, duration]);

  return <canvas ref={ref} className="pointer-events-none fixed inset-0 z-[45] h-full w-full" aria-hidden />;
}
