import { useCallback, useEffect, useRef, useState } from "react";
import { ChevronDown } from "lucide-react";
import { SURPRISE, isReached } from "@/lib/surprise";
import { CountdownDisplay } from "./CountdownDisplay";
import { FallingPetals } from "./FallingPetals";
import { Fireworks } from "./Fireworks";
import { GiftBox, type GiftState } from "./GiftBox";
import { LoveLetter } from "./LoveLetter";
import { MusicPlayer } from "./MusicPlayer";
import { Reveal } from "./Reveal";
import { SpaceBackground } from "./SpaceBackground";
import { Sunflower } from "./Sunflower";
import { SunflowerGarden } from "./SunflowerGarden";
import { WelcomeScreen } from "./WelcomeScreen";
import { WhatsAppGift } from "./WhatsAppGift";

const MUSIC_KEY = "universe-music";

/** Ticking clock. `?preview` jumps to 12 s before the 11:11 unlock; `?preview=whatsapp` to 12 s before the 2:11 PM gift. */
function useClock() {
  const [now, setNow] = useState<Date | null>(null);
  useEffect(() => {
    const preview = new URLSearchParams(window.location.search).get("preview");
    const target = preview === "whatsapp" ? SURPRISE.whatsappGiftTime : SURPRISE.activation;
    const offset = preview !== null ? target.getTime() - 12_000 - Date.now() : 0;
    const tick = () => setNow(new Date(Date.now() + offset));
    tick();
    const id = window.setInterval(tick, 1000);
    return () => window.clearInterval(id);
  }, []);
  return now;
}

export function Experience() {
  const now = useClock();
  const [entered, setEntered] = useState(false);
  const [welcomeGone, setWelcomeGone] = useState(false);
  const [playing, setPlaying] = useState(false);
  const [giftOpen, setGiftOpen] = useState(false);
  const [celebrate, setCelebrate] = useState(false);
  const [cinematic, setCinematic] = useState(false);
  const audioRef = useRef<HTMLAudioElement>(null);
  const giftRef = useRef<HTMLElement>(null);
  const [letterRun, setLetterRun] = useState(0);
  const birthdayShown = useRef(false);
  const unlockShown = useRef(false);
  const birthdayShownAt = useRef(0);

  const birthdayReached = now ? isReached(SURPRISE.birthday, now) : false;
  const unlocked = now ? isReached(SURPRISE.activation, now) : false;

  // ---- music ----
  const play = useCallback(() => {
    const a = audioRef.current;
    if (!a) return;
    a.volume = 0;
    void a.play().catch(() => setPlaying(false));
    let v = 0;
    const id = window.setInterval(() => {
      v = Math.min(0.5, v + 0.025);
      a.volume = v;
      if (v >= 0.5) window.clearInterval(id);
    }, 100);
  }, []);

  const toggleMusic = () => {
    const a = audioRef.current;
    if (!a) return;
    if (a.paused) {
      sessionStorage.setItem(MUSIC_KEY, "on");
      play();
    } else {
      sessionStorage.setItem(MUSIC_KEY, "off");
      a.pause();
    }
  };

  const enter = () => {
    setEntered(true);
    if (sessionStorage.getItem(MUSIC_KEY) !== "off") play();
    window.setTimeout(() => setWelcomeGone(true), 1400);
  };

  // ---- birthday celebration ----
  useEffect(() => {
    if (!entered || !birthdayReached || birthdayShown.current) return;
    birthdayShown.current = true;
    birthdayShownAt.current = Date.now();
    setCelebrate(true);
    const id = window.setTimeout(() => setCelebrate(false), 8000);
    return () => window.clearTimeout(id);
  }, [entered, birthdayReached]);

  // ---- 11:11 unlock cinematic ----
  useEffect(() => {
    if (!entered || !unlocked || unlockShown.current) return;
    unlockShown.current = true;
    const startId = window.setTimeout(() => {
      setCinematic(true);
      giftRef.current?.scrollIntoView({ behavior: "smooth", block: "center" });
    }, Date.now() - birthdayShownAt.current < 8000 ? 8200 : 600);
    const endId = window.setTimeout(() => setCinematic(false), 15000);
    return () => {
      window.clearTimeout(startId);
      window.clearTimeout(endId);
    };
  }, [entered, unlocked]);

  /** Close the gift, replay the light show, then open it again with a fresh letter. */
  const replayMagic = () => {
    setGiftOpen(false);
    giftRef.current?.scrollIntoView({ behavior: "smooth", block: "start" });
    setCinematic(true);
    window.setTimeout(() => {
      setLetterRun((n) => n + 1);
      setGiftOpen(true);
    }, 1400);
    window.setTimeout(() => setCinematic(false), 7000);
  };

  const giftState: GiftState = giftOpen ? "open" : unlocked ? "ready" : "locked";

  return (
    <div className="relative min-h-screen">
      <SpaceBackground bright={unlocked} />
      <audio
        ref={audioRef}
        src="/audio/moonlight-lullaby.mp3"
        loop
        preload="auto"
        onPlay={() => setPlaying(true)}
        onPause={() => setPlaying(false)}
      />

      {!welcomeGone && <WelcomeScreen leaving={entered} onEnter={enter} />}

      {entered && (
        <>
          <FallingPetals />
          <MusicPlayer playing={playing} onToggle={toggleMusic} />
          <Fireworks active={celebrate || cinematic} />
          {cinematic && <div className="light-rays z-30" aria-hidden />}

          {celebrate && (
            <div className="celebrate-veil pointer-events-none fixed inset-0 z-40 flex items-center justify-center bg-midnight/75 px-6 text-center backdrop-blur-md">
              <div className="animate-rise-in">
                <p className="font-script text-6xl text-gradient-gold text-glow-gold sm:text-8xl">Happy Birthday</p>
                <p className="mt-3 font-display text-2xl italic text-foreground text-glow-moon sm:text-3xl">
                  {SURPRISE.recipientName} 🌻
                </p>
              </div>
            </div>
          )}

          <main className="relative z-10 animate-rise-in" style={{ animationDelay: "0.6s" }}>
            {/* Hero + countdown */}
            <section className="flex min-h-screen flex-col items-center justify-center px-5 pb-16 pt-24 text-center">
              <p className="text-xs uppercase tracking-[0.5em] text-moon/80">under the same moon</p>
              <h1 className="mt-5 font-script text-6xl leading-none text-gradient-gold text-glow-gold sm:text-8xl">
                {birthdayReached ? "Happy Birthday" : "Almost your day"}
              </h1>
              <p className="mt-4 font-display text-xl italic text-foreground/90 sm:text-2xl">
                {SURPRISE.recipientName}, this little universe is all yours.
              </p>

              <div className="mt-12 w-full max-w-2xl rounded-[2rem] glass-card p-6 sm:p-10">
                {birthdayReached ? (
                  <div className="py-4">
                    <p className="font-display text-3xl text-foreground sm:text-4xl">Today is your special day 🎂</p>
                    <p className="mt-3 text-muted-foreground">
                      The stars waited all year for this — happy birthday, my love.
                    </p>
                  </div>
                ) : (
                  <>
                    <h2 className="mb-8 font-display text-2xl text-foreground sm:text-3xl">
                      Counting down to your special day 🌻
                    </h2>
                    <CountdownDisplay target={SURPRISE.birthday} now={now} />
                    <p className="mt-6 text-xs uppercase tracking-[0.35em] text-muted-foreground">
                      29 November 2026
                    </p>
                  </>
                )}
              </div>

              <a
                href="#garden"
                className="mt-14 flex flex-col items-center gap-1 text-xs uppercase tracking-[0.4em] text-muted-foreground transition-colors hover:text-gold"
              >
                scroll
                <ChevronDown className="h-5 w-5 animate-bounce" />
              </a>
            </section>

            <div id="garden">
              <SunflowerGarden bloom={unlocked} />
            </div>

            {/* Gift */}
            <section ref={giftRef} className="relative px-5 py-28 text-center sm:py-36">
              <Reveal>
                <p className="text-xs uppercase tracking-[0.5em] text-gold/80">a gift among the stars</p>
                <h2 className="mt-5 font-display text-4xl font-light italic text-foreground text-glow-moon sm:text-5xl">
                  {giftOpen ? "Made with all my love" : "I have something special for you…"}
                </h2>
              </Reveal>

              <Reveal delay={200}>
                <GiftBox state={giftState} onOpen={() => setGiftOpen(true)} />
              </Reveal>

              {giftState === "locked" && (
                <Reveal delay={300} className="mx-auto max-w-md">
                  <p className="font-display text-2xl italic text-gold-soft text-glow-gold animate-pulse">
                    Waiting for the magic moment…
                  </p>
                  <div className="mt-6 rounded-3xl glass-card p-5">
                    <CountdownDisplay target={SURPRISE.activation} now={now} compact />
                    <p className="mt-4 text-xs uppercase tracking-[0.3em] text-muted-foreground">
                      unlocks at 11:11 AM · 29 November
                    </p>
                  </div>
                </Reveal>
              )}

              {giftState === "ready" && (
                <>
                  {cinematic && (
                    <p className="mb-6 font-display text-xl italic text-foreground/90 animate-rise-in">
                      The magic moment is here ✨
                    </p>
                  )}
                  <p className="font-display text-2xl italic text-gold-soft text-glow-gold animate-pulse">
                    Tap the gift to open it ✨
                  </p>
                </>
              )}

              {giftState === "open" && (
                <div className="mt-4">
                  <LoveLetter key={letterRun} onReplay={replayMagic} />
                </div>
              )}
            </section>

            <WhatsAppGift unlocked={now ? isReached(SURPRISE.whatsappGiftTime, now) : false} now={now} />

            {/* Final */}
            <section className="relative flex min-h-screen flex-col items-center justify-center overflow-hidden px-6 text-center">
              <div className="absolute bottom-0 left-0 hidden items-end gap-2 opacity-90 sm:flex">
                <Sunflower size={90} swayDuration={6} />
                <Sunflower size={64} swayDuration={5} delay={0.8} />
              </div>
              <div className="absolute bottom-0 right-0 flex items-end gap-2 opacity-90">
                <Sunflower size={56} swayDuration={5.4} delay={0.4} />
                <Sunflower size={84} swayDuration={6.4} delay={1} />
              </div>
              <Reveal>
                <span className="mx-auto block w-fit text-6xl text-gold-soft text-glow-gold animate-float" aria-hidden>
                  ✦
                </span>
              </Reveal>
              <Reveal delay={200}>
                <p className="mt-8 max-w-4xl font-script text-5xl leading-tight text-foreground text-glow-moon sm:text-7xl md:text-8xl">
                  You are my favorite star in this universe 🌙🌻
                </p>
              </Reveal>
              <Reveal delay={450}>
                <p className="mt-8 text-sm uppercase tracking-[0.45em] text-muted-foreground">
                  — {SURPRISE.senderSignature}
                </p>
              </Reveal>
            </section>
          </main>
        </>
      )}
    </div>
  );
}
