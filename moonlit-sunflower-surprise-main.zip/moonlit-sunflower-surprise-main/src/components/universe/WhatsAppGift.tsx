import { useState } from "react";
import { Button } from "@/components/ui/button";
import { SURPRISE, buildWhatsAppLink } from "@/lib/surprise";
import { CountdownDisplay } from "./CountdownDisplay";
import { GiftBox } from "./GiftBox";
import { Reveal } from "./Reveal";

/** Second gift: unlocks at 11:11 AM and opens a message box that sends on WhatsApp. */
export function WhatsAppGift({ unlocked, now }: { unlocked: boolean; now: Date | null }) {
  const [open, setOpen] = useState(false);
  const [message, setMessage] = useState<string>(SURPRISE.whatsappMessage);
  const state = open ? "open" : unlocked ? "ready" : "locked";
  const canSend = message.trim().length > 0;

  return (
    <section className="relative px-5 py-24 text-center sm:py-32">
      <Reveal>
        <p className="text-xs uppercase tracking-[0.5em] text-gold/80">one more gift</p>
        <h2 className="mt-5 font-display text-4xl font-light italic text-foreground text-glow-moon sm:text-5xl">
          {open ? "Say it to me, my love 💚" : "A little gift for your words…"}
        </h2>
      </Reveal>

      <Reveal delay={200}>
        <GiftBox state={state} onOpen={() => setOpen(true)} name="the WhatsApp gift" />
      </Reveal>

      {state === "locked" && (
        <div className="mx-auto max-w-md">
          <p className="font-display text-2xl italic text-gold-soft text-glow-gold animate-pulse">
            Opens at 2:11 PM ✨
          </p>
          <div className="mt-6 rounded-3xl glass-card p-5">
            <CountdownDisplay target={SURPRISE.whatsappGiftTime} now={now} compact />
          </div>
        </div>
      )}

      {state === "ready" && (
        <p className="font-display text-2xl italic text-gold-soft text-glow-gold animate-pulse">
          Tap the gift to open it ✨
        </p>
      )}

      {state === "open" && (
        <div className="mx-auto mt-2 w-full max-w-xl animate-rise-in rounded-[2rem] glass-card p-6 text-left sm:p-8">
          <label htmlFor="whatsapp-message" className="block text-center font-script text-4xl text-gradient-gold">
            Write your message
          </label>
          <textarea
            id="whatsapp-message"
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            rows={5}
            placeholder="Type anything your heart wants to say…"
            className="mt-5 w-full resize-none rounded-2xl border border-glass-border bg-midnight/50 p-4 font-hand text-xl leading-relaxed text-foreground placeholder:text-muted-foreground/70 focus:border-gold/60 focus:outline-none focus:glow-gold"
          />
          <div className="mt-6 flex justify-center">
            {canSend ? (
              <Button variant="whatsapp" size="xl" asChild>
                <a href={buildWhatsAppLink(SURPRISE.whatsappPhone, message.trim())} target="_blank" rel="noopener noreferrer">
                  Open on WhatsApp 💚
                </a>
              </Button>
            ) : (
              <Button variant="whatsapp" size="xl" disabled>
                Open on WhatsApp 💚
              </Button>
            )}
          </div>
          <p className="mt-4 text-center text-xs text-muted-foreground">
            WhatsApp opens with your message ready — nothing is sent until you press send there.
          </p>
        </div>
      )}
    </section>
  );
}
