import { useEffect, useRef } from "react";
import spaceMoon from "@/assets/space-moon.jpg";
import { cn } from "@/lib/utils";
import { Starfield } from "./Starfield";

/** Fixed cinematic sky: HD moon photo, drifting nebula, starfield, mouse/touch parallax. */
export function SpaceBackground({ bright = false }: { bright?: boolean }) {
  const rootRef = useRef<HTMLDivElement>(null);
  const pointer = useRef({ x: 0, y: 0 });

  useEffect(() => {
    const onMove = (e: PointerEvent) => {
      const x = (e.clientX / window.innerWidth) * 2 - 1;
      const y = (e.clientY / window.innerHeight) * 2 - 1;
      pointer.current = { x, y };
      rootRef.current?.style.setProperty("--mx", x.toFixed(3));
      rootRef.current?.style.setProperty("--my", y.toFixed(3));
    };
    window.addEventListener("pointermove", onMove, { passive: true });
    return () => window.removeEventListener("pointermove", onMove);
  }, []);

  const layer = (depth: number) => ({
    transform: `translate3d(calc(var(--mx, 0) * ${-depth}px), calc(var(--my, 0) * ${-depth * 0.7}px), 0)`,
  });

  return (
    <div ref={rootRef} className="fixed inset-0 -z-10 overflow-hidden bg-midnight" aria-hidden>
      <div className="absolute -inset-[6%] transition-transform duration-700 ease-out" style={layer(18)}>
        <img
          src={spaceMoon}
          alt=""
          className={cn(
            "h-full w-full object-cover object-[82%_center] transition-[filter] duration-[3000ms]",
            bright ? "brightness-125 saturate-125" : "brightness-90",
          )}
        />
      </div>

      {/* Moonlight halo (upper right, over the photo's moon) */}
      <div
        className="absolute right-[2%] top-[12%] h-[55vmin] w-[55vmin] transition-transform duration-700 ease-out sm:right-[8%]"
        style={layer(24)}
      >
        <div
          className={cn(
            "h-full w-full rounded-full animate-moon-breathe transition-opacity duration-[3000ms]",
            "bg-[radial-gradient(circle,var(--moon)_0%,transparent_65%)] mix-blend-screen blur-2xl",
            bright ? "opacity-100" : "opacity-40",
          )}
        />
      </div>

      {/* Nebula clouds */}
      <div className="absolute inset-0 mix-blend-screen" style={layer(40)}>
        <div className="absolute -left-[20%] top-[10%] h-[70vmax] w-[70vmax] rounded-full bg-[radial-gradient(circle,var(--violet)_0%,transparent_60%)] opacity-40 blur-3xl animate-nebula" />
        <div
          className="absolute -right-[25%] bottom-[-20%] h-[60vmax] w-[60vmax] rounded-full bg-[radial-gradient(circle,var(--petal-deep)_0%,transparent_60%)] opacity-15 blur-3xl animate-nebula"
          style={{ animationDelay: "-12s", animationDuration: "36s" }}
        />
      </div>

      <Starfield pointer={pointer} />

      {/* Vignette for text legibility */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,transparent_30%,var(--midnight)_100%)] opacity-70" />
    </div>
  );
}
