import { createFileRoute } from "@tanstack/react-router";
import { Experience } from "@/components/universe/Experience";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "A Little Universe For You 🌙🌻" },
      {
        name: "description",
        content: "A moonlit birthday surprise with stars, sunflowers, a secret gift and a letter written just for you.",
      },
      { property: "og:title", content: "A Little Universe For You 🌙🌻" },
      {
        property: "og:description",
        content: "A moonlit birthday surprise with stars, sunflowers, a secret gift and a letter written just for you.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

function Index() {
  return <Experience />;
}
