import garden from "@/assets/sunflower-garden.jpg";
import { Reveal } from "./Reveal";
import { Sunflower } from "./Sunflower";

const FRONT_ROW = [
  { size: 70, dur: 5.2, delay: 0, offset: 10 },
  { size: 96, dur: 6.1, delay: 0.4, offset: 0 },
  { size: 60, dur: 4.6, delay: 0.9, offset: 26 },
  { size: 110, dur: 6.8, delay: 0.2, offset: -6 },
  { size: 64, dur: 5.5, delay: 1.2, offset: 22 },
  { size: 88, dur: 5.9, delay: 0.6, offset: 4 },
  { size: 72, dur: 4.9, delay: 1.5, offset: 16 },
];

export function SunflowerGarden({ bloom }: { bloom: boolean }) {
  return (
    <section className="relative overflow-hidden py-28 sm:py-36">
      <div className="absolute inset-0">
        <img src={garden} alt="" loading="lazy" className="h-full w-full object-cover object-bottom opacity-70" />
        <div className="absolute inset-0 bg-[linear-gradient(180deg,var(--midnight)_0%,transparent_30%,transparent_70%,var(--midnight)_100%)]" />
      </div>

      <div className="relative mx-auto max-w-3xl px-6 text-center">
        <Reveal>
          <p className="text-xs uppercase tracking-[0.5em] text-gold/80">the sunflower garden</p>
        </Reveal>
        <Reveal delay={150}>
          <h2 className="mt-5 font-display text-4xl font-light italic leading-tight text-foreground text-glow-moon sm:text-6xl">
            Sunflowers turn to the sun.
            <br />
            <span className="font-script not-italic text-gradient-gold text-5xl sm:text-7xl">I turn to you.</span>
          </h2>
        </Reveal>
        <Reveal delay={300}>
          <p className="mx-auto mt-6 max-w-lg text-base leading-relaxed text-muted-foreground sm:text-lg">
            Every petal here is a moment you made brighter — the quiet ones, the silly ones, and the ones I'll keep
            forever.
          </p>
        </Reveal>
      </div>

      <Reveal delay={200} className="relative mt-16">
        <div className="flex items-end justify-center gap-1 sm:gap-6">
          {FRONT_ROW.map((f, i) => (
            <div key={i} style={{ marginBottom: f.offset }} className={i > 4 ? "hidden sm:block" : undefined}>
              <Sunflower size={f.size} swayDuration={f.dur} delay={f.delay} bloom={bloom} />
            </div>
          ))}
        </div>
      </Reveal>
    </section>
  );
}
