import { Lock } from "lucide-react";
import { cn } from "@/lib/utils";
import { Sunflower } from "./Sunflower";

export type GiftState = "locked" | "ready" | "open";

const BURST = Array.from({ length: 28 }, (_, i) => {
  const angle = (i / 28) * Math.PI * 2 + Math.sin(i * 7.3) * 0.3;
  const dist = 140 + ((Math.sin(i * 3.7) + 1) / 2) * 200;
  return {
    tx: `${Math.round(Math.cos(angle) * dist)}px`,
    ty: `${Math.round(Math.sin(angle) * dist - 120)}px`,
    rot: `${Math.round(Math.sin(i * 1.9) * 540)}deg`,
    delay: `${(i % 7) * 0.06}s`,
    dur: `${2 + (i % 5) * 0.3}s`,
    kind: i % 3 === 0 ? "star" : "petal",
  };
});

/** CSS-3D gift box: floats and pulses; lid flies off, light beam and petals burst when opened. */
export function GiftBox({
  state,
  onOpen,
  name = "the gift",
}: {
  state: GiftState;
  onOpen: () => void;
  name?: string;
}) {
  const interactive = state === "ready";
  return (
    <div className="relative flex h-[360px] w-full items-center justify-center">
      {/* golden aura */}
      <div
        className={cn(
          "absolute h-72 w-72 rounded-full bg-[radial-gradient(circle,var(--gold)_0%,transparent_65%)] blur-2xl transition-opacity duration-1000",
          state === "locked" ? "opacity-15" : "opacity-45",
          state === "open" && "opacity-80",
        )}
      />
      {state === "open" && <div className="gift-beam" />}

      <button
        type="button"
        onClick={interactive ? onOpen : undefined}
        disabled={state === "locked"}
        aria-label={
          state === "locked" ? `${name} is locked for now` : state === "ready" ? `Open ${name}` : `${name} opened`
        }
        className={cn(
          "gift-scene relative mt-16 outline-none",
          interactive && "cursor-pointer",
          state === "locked" && "cursor-not-allowed",
        )}
      >
        <div className={cn(state !== "open" && "animate-float", interactive && "animate-pulse-glow")}>
          <div
            className={cn(
              "gift-3d",
              state === "open" && "is-open",
              state === "locked" && "is-locked",
              interactive && "hover:[transform:rotateX(-20deg)_rotateY(-20deg)]",
            )}
          >
            <div className="gift-inner" />
            <div className="gift-face back" />
            <div className="gift-face left" />
            <div className="gift-face right" />
            <div className="gift-face front">
              {state === "locked" && (
                <span className="absolute left-1/2 top-1/2 grid h-12 w-12 -translate-x-1/2 -translate-y-1/2 place-items-center rounded-full bg-midnight/80 ring-2 ring-gold/60">
                  <Lock className="h-5 w-5 text-gold" />
                </span>
              )}
            </div>
            <div className="gift-lid">
              <div className="gift-lid-face top" />
              <div className="gift-lid-face back" />
              <div className="gift-lid-face left" />
              <div className="gift-lid-face right" />
              <div className="gift-lid-face front" />
              <div className="gift-bow">
                <svg width="110" height="70" viewBox="0 0 110 70" aria-hidden>
                  <path d="M55 52 C 30 10, 0 20, 12 44 C 20 58, 42 58, 55 52 Z" className="fill-gold" />
                  <path d="M55 52 C 80 10, 110 20, 98 44 C 90 58, 68 58, 55 52 Z" className="fill-gold" />
                  <path d="M55 52 C 36 26, 18 30, 20 42" className="stroke-petal-deep" strokeWidth="2" fill="none" />
                  <path d="M55 52 C 74 26, 92 30, 90 42" className="stroke-petal-deep" strokeWidth="2" fill="none" />
                  <circle cx="55" cy="52" r="9" className="fill-gold-soft" />
                </svg>
              </div>
            </div>
          </div>
        </div>
      </button>

      {/* sparkles around the box */}
      {state !== "locked" &&
        [0, 1, 2, 3, 4, 5].map((i) => (
          <span
            key={i}
            className="absolute text-gold animate-pulse"
            style={{
              left: `${50 + Math.cos(i) * 32}%`,
              top: `${45 + Math.sin(i * 2) * 30}%`,
              animationDelay: `${i * 0.4}s`,
              fontSize: `${10 + (i % 3) * 6}px`,
            }}
            aria-hidden
          >
            ✦
          </span>
        ))}

      {state === "open" && (
        <div className="pointer-events-none absolute left-1/2 top-[55%]" aria-hidden>
          {BURST.map((b, i) => (
            <span
              key={i}
              className="burst-particle"
              style={
                { "--tx": b.tx, "--ty": b.ty, "--rot": b.rot, "--delay": b.delay, "--dur": b.dur } as React.CSSProperties
              }
            >
              {b.kind === "star" ? (
                <span className="text-xl text-gold-soft text-glow-gold">✦</span>
              ) : (
                <svg width="12" height="24" viewBox="0 0 20 40">
                  <ellipse cx="10" cy="20" rx="7" ry="18" className="fill-petal" />
                </svg>
              )}
            </span>
          ))}
          <span className="burst-particle" style={{ "--tx": "-160px", "--ty": "-220px", "--rot": "200deg" } as React.CSSProperties}>
            <Sunflower size={40} stem={false} />
          </span>
          <span className="burst-particle" style={{ "--tx": "170px", "--ty": "-200px", "--rot": "-220deg" } as React.CSSProperties}>
            <Sunflower size={34} stem={false} />
          </span>
        </div>
      )}
    </div>
  );
}
