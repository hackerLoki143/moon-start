import { getTimeLeft } from "@/lib/surprise";
import { cn } from "@/lib/utils";

const UNITS = [
  ["days", "Days"],
  ["hours", "Hours"],
  ["minutes", "Minutes"],
  ["seconds", "Seconds"],
] as const;

export function CountdownDisplay({
  target,
  now,
  compact = false,
}: {
  target: Date;
  now: Date | null;
  compact?: boolean;
}) {
  const t = now ? getTimeLeft(target, now) : null;
  return (
    <div className={cn("grid grid-cols-4", compact ? "gap-2 sm:gap-3" : "gap-3 sm:gap-5")}>
      {UNITS.map(([key, label]) => (
        <div
          key={key}
          className={cn(
            "flex flex-col items-center rounded-2xl border border-glass-border bg-midnight/40",
            compact ? "px-2 py-3 sm:px-4" : "px-2 py-4 sm:px-6 sm:py-6",
          )}
        >
          <span
            key={t ? t[key] : "x"}
            className={cn(
              "animate-in fade-in slide-in-from-top-2 duration-500 font-display font-semibold tabular-nums text-gradient-gold",
              compact ? "text-3xl sm:text-4xl" : "text-4xl sm:text-6xl",
            )}
          >
            {t ? String(t[key]).padStart(2, "0") : "--"}
          </span>
          <span className="mt-1 text-[0.65rem] uppercase tracking-[0.3em] text-muted-foreground sm:text-xs">
            {label}
          </span>
        </div>
      ))}
    </div>
  );
}
